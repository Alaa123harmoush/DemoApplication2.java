package com.example.demo.api.model;

public class Depatment {
    private int id;
    private string name;
}
