package com.example.demo.api.controller;

public class departmentControler {
}
